This assignment was done using the search.py folder, and there have been changes to it.

The answer to question 1 is in wordladder.py.
The answer to question 2 is in flightitinerary.py, and the comments section answers the non-coding questions as well.

There are some test cases written in each of the files for each of the questions, if you wish to run it, just call the functions.